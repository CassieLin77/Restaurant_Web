# db_operations.py
from sqlalchemy import text
from flask import g

def execute_query(query, params=None):
    """Execute a SQL query and return the results."""
    if params is None:
        params = {}
    cursor = g.conn.execute(text(query), **params)
    results = cursor.fetchall()
    cursor.close()
    return results

def generate_and_execute_sql_query(price_ranges=None, cuisines=None, food_feature=None, sort=None):
    base_query = """
    SELECT r.restaurant_id, r.name, r.rating, r.description, r.cuisine_type, r.address, r.price_range,
           (SELECT COUNT(*) FROM reviews rev WHERE rev.restaurant_id = r.restaurant_id) AS review_count,
           (r.rating + r.rating * LOG(GREATEST((SELECT COUNT(*) FROM reviews rev WHERE rev.restaurant_id = r.restaurant_id), 1))) AS recommendation_score
    FROM restaurants r
    """

    # Initialize list to store WHERE clause conditions
    where_conditions = []
    
    # Generate WHERE clause based on filters
    if price_ranges:
        sanitized_prices = ["'" + pr.replace("'", "''") + "'" for pr in price_ranges]
        price_condition = f"price_range IN ({', '.join(sanitized_prices)})"
        where_conditions.append(price_condition)

    if food_feature or cuisines:
        combined_filters = (food_feature or []) + (cuisines or [])
        if combined_filters:
            sanitized_filters = ["'" + f.replace("'", "''") + "'" for f in combined_filters]
            filters_condition = f"cuisine_type IN ({', '.join(sanitized_filters)})"
            where_conditions.append(filters_condition)

    # Append WHERE clause to base query if conditions exist
    if where_conditions:
        base_query += " WHERE " + " AND ".join(where_conditions)
    
    # Adjusting the ORDER BY clause based on the sort parameter
    if sort == 'most_reviewed':
        base_query += " ORDER BY review_count DESC"
    elif sort == 'highest_rated':
        base_query += " ORDER BY rating DESC"
    else:
        base_query += " ORDER BY recommendation_score DESC"

    base_query += " LIMIT 10" 

    return execute_query(base_query)



def fetch_latest_review(restaurant_id):
    """Fetch the most recent review for a given restaurant and the total number of reviews."""
    
    # Query to fetch the latest review content
    review_query = """
    SELECT 
        content AS latest_review
    FROM 
        reviews
    WHERE 
        restaurant_id = :restaurant_id
    ORDER BY 
        timestamp DESC
    LIMIT 1;
    """
    
    # Execute the query to fetch the latest review
    review_cursor = g.conn.execute(text(review_query), {'restaurant_id': restaurant_id})
    latest_review = review_cursor.fetchone()
    
    # Return the results
    return latest_review



def fetch_restaurants_with_reviews(price_ranges=None, cuisines = None, food_feature=None, sort = None):
    """
    Fetch details of all restaurants, optionally filtered by price ranges,
    and their most recent review.

    Parameters:
    - price_ranges (list of str): Optional list of price ranges to filter by.

    Returns:
    - list of dict: Each dictionary contains details of a restaurant and its latest review.
    """
    # Fetch restaurants with optional price range filtering
    restaurants = generate_and_execute_sql_query(price_ranges, cuisines, food_feature, sort)
    results = []
    
    for restaurant in restaurants:
        # Extract restaurant_id for the current restaurant
        restaurant_id = restaurant[0]
        # Fetch the latest review for the current restaurant
        latest_review= fetch_latest_review(restaurant_id)
        # Prepare the combined restaurant data, including the latest review
        restaurant_data = {
            'name': restaurant[1],
            'rating': restaurant[2],
            'review_count': restaurant[7], 
            'description': restaurant[3],
            'category': restaurant[4],
            'price_range': restaurant[6],
            'location': restaurant[5],
            'latest_review': latest_review[0] if latest_review else 'No reviews yet'
        }
        results.append(restaurant_data)
    
    return results
