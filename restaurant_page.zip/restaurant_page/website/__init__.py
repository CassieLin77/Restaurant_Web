import os
from flask import Flask, g
from sqlalchemy import *
from .routes import main

DATABASE_USERNAME = "jy3343"
DATABASE_PASSWRD = "001017"
DATABASE_HOST = "35.212.75.104"
DATABASEURI = f"postgresql://{DATABASE_USERNAME}:{DATABASE_PASSWRD}@{DATABASE_HOST}/proj1part2"
engine = create_engine(DATABASEURI)


def create_app():
    app = Flask(__name__)
    @app.before_request
    def before_request():
        """
        This function is run at the beginning of every web request 
        (every time you enter an address in the web browser).
        We use it to setup a database connection that can be used throughout the request.

        The variable g is globally accessible.
        """
        try:
            g.conn = engine.connect()
        except:
            print("uh oh, problem connecting to database")
            import traceback; traceback.print_exc()
            g.conn = None
    @app.teardown_request
    def teardown_request(exception):
        """
        At the end of the web request, this makes sure to close the database connection.
        If you don't, the database could run out of memory!
        """
        try:
            g.conn.close()
        except Exception as e:
            pass
    app.register_blueprint(main)
    return app

