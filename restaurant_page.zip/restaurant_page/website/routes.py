from flask import render_template, Blueprint, g, request, jsonify
from sqlalchemy import text
from .db_operations import execute_query, generate_and_execute_sql_query, fetch_latest_review, fetch_restaurants_with_reviews
from openai import OpenAI



main = Blueprint('main', __name__)


@main.route('/')
def index():
    results = fetch_restaurants_with_reviews()
    return render_template('home.html', restaurants = results )


@main.route('/filter', methods=['POST'])
def filter():
    data = request.json
    price_ranges = data['priceRanges']
    cuisines = data['cuisines']
    food_feature = data['food_feature']
    sort = data['sort']
    restaurants= fetch_restaurants_with_reviews(price_ranges, cuisines, food_feature, sort)
    return restaurants



@main.route("/ask", methods=['POST'])
def ask():
    user_input = request.form['question']

    ai_response = process_input(user_input)
    return jsonify({'response': ai_response})

def process_input(user_input):
    client = OpenAI(api_key='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')
    response = client.chat.completions.create(model="gpt-4-turbo-preview",
    messages=[
        {
            "role": "system",
            "content": """
            You are a VERY consise chatbox that is wrapped in a webpage. You goal is to explain how the webpage work. 
            
            Your answer to the question must be very short and polite and it only needs to solve the users question efficiently. After answering a question 
            base on what you know, propose politely to the user what question they should ask to get good insights about the webpage. 

            Here is the information you need to know.

            First, This is a restaurant filtering page. As a user may see, there are filters by price, cuisine, and specific food features; 
            the user can also choose to see the returned restaurants in the ways they like. The results will be sorted in default by 'recommended,'
            which takes considerration of both the number of reviews and the rating level. Other sorting choices are to sort by review and rating. 
            Once clicking on the filters the appropriate data will automatically show. 

            More importantly, how the filters work(tell users how the filter works when asked questions like 'how does the webpage work'): the price 
            filter selected with another filter will always produce a intersection of restaurants with the corresponding features.Other 
            filters will produce a union. For example, ticking "$", "American", and "Coffee and Tea", will show "American"/"Coffee and Tea" 
            restaurants that are "$" 

            Second, the data are extracted from the database through dynamically generated sql queries. As a filter is ticked, the front end 
            sends data in the backend to generate a sql query, which is then executed to extract data and dnamically display on the webpage.  
            
            The logic of generate_and_execute_sql_query is that the page uses a base query. Then create a where condition string to append 
            to the base query as well as sorting mechanism selected by the users. After all filters and sorts are fullfilled, execute the 
            query. 

             """
        },
        {
            "role": "user",
            "content": f"{user_input}"
        }
    ])
    return response.choices[0].message.content.strip()


